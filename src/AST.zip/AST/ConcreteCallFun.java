package AST;

public class ConcreteCallFun extends callFun{
    public ConcreteCallFun() {
        super("call fun");

    }


}
