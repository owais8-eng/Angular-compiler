package AST;

public interface htmlContent  {



}
